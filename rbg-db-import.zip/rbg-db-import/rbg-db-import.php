<?php
/*
 * Plugin Name: RBG Demo Database Import
 * Description: One-off helper for moving the RBG coursework demo. Tools > RBG DB import replaces this site's database with the bundled demo database. Delete it afterwards.
 * Version: 1.0
 * Requires PHP: 7.4
 */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_management_page( 'RBG DB import', 'RBG DB import', 'manage_options', 'rbg-db-import', function () {
		echo '<div class="wrap"><h1>RBG DB import</h1>';
		echo '<p>This replaces the whole database with the RBG coursework demo. You will be logged out afterwards; log in again as akindu with the same password.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'rbg_db_import' );
		echo '<input type="hidden" name="action" value="rbg_db_import">';
		echo '<button type="submit" class="button button-primary" id="rbg-db-import-go">Import database</button></form></div>';
	} );
} );

add_action( 'admin_post_rbg_db_import', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.' );
	}
	check_admin_referer( 'rbg_db_import' );
	@set_time_limit( 120 );

	$sql = file_get_contents( __DIR__ . '/rbg-hosted.sql' );
	if ( ! $sql ) {
		wp_die( 'SQL file missing.' );
	}
	$host = DB_HOST;
	$port = 3306;
	if ( strpos( $host, ':' ) !== false ) {
		list( $host, $port ) = explode( ':', $host, 2 );
		$port = (int) $port;
	}
	mysqli_report( MYSQLI_REPORT_OFF );
	$db = new mysqli( $host, DB_USER, DB_PASSWORD, DB_NAME, $port );
	if ( $db->connect_errno ) {
		wp_die( 'Database connection failed: ' . esc_html( $db->connect_error ) );
	}
	$db->set_charset( 'utf8mb4' );

	$count = 0;
	if ( $db->multi_query( $sql ) ) {
		do {
			$count++;
			if ( $result = $db->store_result() ) {
				$result->free();
			}
		} while ( $db->more_results() && $db->next_result() );
	}
	$error = $db->errno ? $db->error : '';
	$db->close();

	nocache_headers();
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo $error ? "RBG-IMPORT-FAILED after {$count} statements: {$error}" : "RBG-IMPORT-OK {$count} statements";
	exit;
} );
