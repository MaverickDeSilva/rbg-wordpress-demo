<?php
/*
 * Plugin Name: RBG Demo Media Import
 * Description: One-off helper for moving the RBG coursework demo. On activation it copies the bundled images and fonts into wp-content/uploads. Delete it afterwards.
 * Version: 1.0
 * Requires PHP: 7.4
 */
defined( 'ABSPATH' ) || exit;

register_activation_hook( __FILE__, function () {
	$src = __DIR__ . '/uploads';
	$dst = untrailingslashit( wp_get_upload_dir()['basedir'] );
	$copied = 0;
	$failed = array();
	$items = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $src, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::SELF_FIRST
	);
	foreach ( $items as $item ) {
		$rel    = ltrim( substr( $item->getPathname(), strlen( $src ) ), '/\\' );
		$target = $dst . '/' . $rel;
		if ( $item->isDir() ) {
			wp_mkdir_p( $target );
			continue;
		}
		wp_mkdir_p( dirname( $target ) );
		if ( @copy( $item->getPathname(), $target ) ) {
			$copied++;
		} else {
			$failed[] = $rel;
		}
	}
	update_option( 'rbg_media_import_result', array( 'copied' => $copied, 'failed' => $failed ), false );
} );

add_action( 'admin_notices', function () {
	$r = get_option( 'rbg_media_import_result' );
	if ( ! is_array( $r ) ) {
		return;
	}
	$msg = sprintf( 'RBG media import: %d files copied to uploads.', (int) $r['copied'] );
	if ( $r['failed'] ) {
		$msg .= ' Failed: ' . esc_html( implode( ', ', $r['failed'] ) );
	}
	echo '<div class="notice notice-' . ( $r['failed'] ? 'warning' : 'success' ) . '"><p id="rbg-media-import-result">' . esc_html( $msg ) . '</p></div>';
} );
